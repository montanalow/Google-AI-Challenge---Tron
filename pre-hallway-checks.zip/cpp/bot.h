/* 
 * File:   bot.h
 * Author: montana
 *
 * Created on February 8, 2010, 2:49 PM
 */

#ifndef _ZZ_BOT_H
#define	_ZZ_BOT_H

#include "map.h"
#include <stdio.h>

namespace zz {
  class bot {

  public:
    typedef int script;
    
    bot( );
    virtual ~bot( );

    void set_map(FILE * file);
    void move( );

  private:
    void set_depth();
    void minimax( int depth, bool use_heuristic = true );
    
    // Sends the bots move to the contest engine.
    void move_first( int moves[], int count_moves );
    void move_random( int moves[], int count_moves );
    void move_to_wall( int moves[], int count_moves, bool to_walls = true );
    void move_closer( int moves[], int count_moves );

    void output_move( zz::map::direction direction );

    zz::map _map;
    int _depth;
    bool _players_are_connected;
  };
}


#endif	/* _ZZ_BOT_H */

