/* 
 * File:   Bot.cpp
 * Author: montana
 * 
 * Created on February 8, 2010, 2:49 PM
 */

#include "bot.h"
#include "config.h"

#include <stdio.h>
#include <time.h>
#include <math.h>
#include <limits.h>
#include <algorithm>


zz::bot::bot( )
: _depth( 3 ), _players_are_connected( true ) {
  srand( time( NULL ) );
}

zz::bot::~bot( ) {
}

void zz::bot::set_map( FILE * file ) {
  _map.load_from_file( file );
}

void zz::bot::set_depth() {
  // figure out how long it takes to calculate the area of a leaf, by timing a
  // minimax run and counting the leafs at that depth, since 99% of a minimax
  // run is actually spent calculating the heuristic value of a leaf
  clock_t timer = 0;
  int test_depth = 2;
  while( timer == 0 ) {
    // if minimax is faster than the resolution of clock() we'll need to test until we do enough work to actually time it
    timer = clock( );
    minimax( test_depth );
    timer = clock( ) - timer;
  }

  // calculate the max number of leafs we can handle in 1 second
  int leafs = zz::map::__minimax_leafs;
  float clocks_per_leaf = ( float ) timer / leafs;
  int max_leafs = (CLOCKS_PER_SEC / clocks_per_leaf) * 0.95; // give up 5% for overhead

  // find the max minimax depth, with fewer than max_leafs
  do {
    // see how many leafs are at the current depth
    timer = clock( );
    minimax( _depth, false );
    max_leafs -= ( clock( ) - timer ) / clocks_per_leaf; // we burned some time
    leafs = zz::map::__minimax_leafs;
#ifdef DEBUG_BOT
  fprintf( stderr, " leafs: %8d | max_leafs: %8d | depth: %2d | %-.4fs\n", leafs, max_leafs, _depth, (float) ( clock( ) - timer ) / CLOCKS_PER_SEC );
#endif

    // guess at the max depth
    if( leafs * 6 < max_leafs ) {
      _depth++;
    }
    if( leafs > max_leafs ) {
      _depth--;
    }
  } while( leafs > 0 && max_leafs > 0 && ( leafs > max_leafs || leafs * 6 < max_leafs ) );
}

void zz::bot::minimax( int depth, bool use_heuristic ){
  zz::map::__minimax_leafs = 0;
  if( _players_are_connected ) {
    _map.minimax( depth, use_heuristic );
  } else {
    _map.solomax( depth, use_heuristic );
  }
}

void zz::bot::move( ) {
#ifdef DEBUG_BOT
  fprintf( stderr, "(%d,%d) vs (%d,%d) calculating move:\n", _map.player_one().x(), _map.player_one().y(), _map.player_two().x(), _map.player_two().y() );
#endif
  // determins the basic strategy of minimax vs solomax
  if( _players_are_connected ) {
    _players_are_connected = _map.locations_are_connected( _map.player_one( ), _map.player_two( ) );
    if( !_players_are_connected )
      _depth = 3; // we are gonna switch from minimax to solomax, solomax can't alpha-beta prune, so we need to start low again
  }

  set_depth();

  // find the best possible hueristic solution to the board using _depth
  clock_t timer = clock( );
  minimax( _depth );
  timer = clock( ) - timer;

  // build a list of the best moves
  int count_moves = 0;
  int moves[4];
  for( int i = 0; i < 4; ++i){
    if( _map.mins()[i] == _map.max() ){
      moves[count_moves++] = i;
    }
  }

#ifdef DEBUG_BOT
  fprintf( stderr, " %s(%d): [", _players_are_connected ? "minimax" : "solomax", _depth );
  for( int i = 0; i < 4; ++i ) {
    fprintf( stderr, "%d:%d", i, _map.mins()[i] );
    if( i !=  3) fprintf( stderr, ", " );
  }
  fprintf( stderr, "] (%d) %-.4fs\n", _map.max(), (float) timer / CLOCKS_PER_SEC );
#endif

  move_to_wall( moves, count_moves );
}

void zz::bot::move_first( int moves[], int count_moves ) {
  output_move( moves[0] );
}

void zz::bot::move_random( int moves[], int count_moves ) {
  int index = rand( ) % count_moves;
#ifdef DEBUG_BOT
    fprintf( stderr, " move_random: [" );
    for( int i = 0; i < count_moves; ++i ) {
      fprintf( stderr, "%d:%d", moves[i], i == index );
      if( i != count_moves - 1) fprintf( stderr, ", " );
    }
    fprintf( stderr, "]\n" );
#endif
  output_move( moves[index] );
}

void zz::bot::move_to_wall( int moves[], int count_moves, bool to_walls ) {
  if( count_moves == 1 ) {
    // don't bother if there is only 1 move
    move_first( moves, count_moves );
  } else {
    clock_t timer = clock( );
    // calc the number of walls next to each square
    int moves_walls[count_moves];
    for( int i = 0; i < count_moves; ++i ) {
      moves_walls[i] = 0;
      zz::map::location next_spot = _map.player_one( ).adjacent( moves[i] );
      for( int j = 0; j < 4; ++j ) {
        if( _map.is_wall( next_spot.adjacent( j ) ) ) {
          ++moves_walls[i];
        }
      }
    }

    // find the moves with the most walls
    int max_walls;
    if( to_walls ) {
      max_walls = *std::max_element( moves_walls, moves_walls + count_moves );
    }else {
      max_walls = *std::min_element( moves_walls, moves_walls + count_moves );
    }
    int max_wall_moves[count_moves];
    int count_max_wall_moves = 0;
    for( int i = 0; i < count_moves; ++i ){
      if( moves_walls[i] >= max_walls ) {
        max_wall_moves[count_max_wall_moves++] = moves[i];
      }
    }

  #ifdef DEBUG_BOT
    fprintf( stderr, " move_to_wall: [" );
    for( int i = 0; i < count_moves; ++i ) {
      fprintf( stderr, "%d:%d", moves[i], moves_walls[i] );
      if( i != count_moves - 1) fprintf( stderr, ", " );
    }
    fprintf( stderr, "] (%d) %-.4fs\n", max_walls, ( float ) ( clock( ) - timer ) / CLOCKS_PER_SEC );
  #endif

    if( count_max_wall_moves > 1 ){
      move_random( max_wall_moves, count_max_wall_moves );
    } else {
      move_first( max_wall_moves, count_max_wall_moves );
    }
  }
}

void zz::bot::move_closer( int moves[], int count_moves ) {
  if( count_moves == 1 ) {
    // don't bother if there is only 1 move
    move_first( moves, count_moves );
  } else {
    clock_t timer = clock( );
    // provide a default destination
    zz::map::location destination = _map.player_two( );

    // find the distance for all moves from the destination
    int moves_distances[count_moves];
    for( int i = 0; i < count_moves; ++i ) {
      zz::map::location next_spot = _map.player_one( ).adjacent( moves[i] );
      moves_distances[i] = pow( next_spot.x( ) - destination.x( ), 2 ) + pow( next_spot.y( ) - destination.y( ), 2 );
    }

    // collect all moves that have the minimum distance
    int min_distance = *std::min_element( moves_distances, moves_distances + count_moves);
    int closer_moves[count_moves];
    int count_closer_moves = 0;
    for( int i = 0; i < count_moves; ++i ){
      if( moves_distances[i] <= min_distance ) {
        closer_moves[count_closer_moves++] = moves[i];
      }
    }

#ifdef DEBUG_BOT
    fprintf( stderr, " move_closer: [" );
    for( int i = 0; i < count_moves; ++i ) {
      fprintf( stderr, "%d:%d", moves[i], moves_distances[i] );
      if( i != count_moves - 1) fprintf( stderr, ", " );
    }
    fprintf( stderr, "] (%d) %-.4fs\n", min_distance, ( float ) ( clock( ) - timer ) / CLOCKS_PER_SEC );
#endif
    
    if( count_closer_moves > 1 ) {
      move_to_wall( closer_moves, count_closer_moves );
    } else {
      move_first( closer_moves, count_closer_moves );
    }
  }
}

void zz::bot::output_move( zz::map::direction direction ) {
  // The four possible moves the contest engine recognizes are:
  //   * 1 -- North. Negative Y direction.
  //   * 2 -- East. Positive X direction.
  //   * 3 -- South. Positive X direction.
  //   * 4 -- West. Negative X direction.
  int move = 1;
  switch( direction ) {
    case zz::map::north :
#ifdef DEBUG_BOT
      fprintf( stderr, "Moving North!\n" );
#endif
      move = 1;
      break;
    case zz::map::east :
#ifdef DEBUG_BOT
      fprintf( stderr, "Moving East!\n" );
#endif
      move = 2;
      break;
    case zz::map::south :
#ifdef DEBUG_BOT
      fprintf( stderr, "Moving South!\n" );
#endif
      move = 3;
      break;
    case zz::map::west :
#ifdef DEBUG_BOT
      fprintf( stderr, "Moving West!\n" );
#endif
      move = 4;
      break;
  }

  fprintf( stdout, "%d\n", move );
  fflush( stdout );
}
