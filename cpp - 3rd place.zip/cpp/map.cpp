/*
 * File:   Map.cpp
 * Author: montana
 *
 * Created on February 8, 2010, 2:49 PM
 */

#include "map.h"
#include "bot.h"

/******************************************************************************
 * Define the Location Class
 ******************************************************************************/
zz::map::location::location( coordinate x, coordinate y )
: _x( x ), _y( y ) {
}

zz::map::location::location( const location& location )
: _x( location._x ), _y( location._y ) {
}

zz::map::location::~location( ) {
}

zz::map::location zz::map::location::adjacent( zz::map::direction direction ) const {
  switch( direction ) {
    case zz::map::north :
      return north( );
    case zz::map::east :
      return east( );
    case zz::map::south :
      return south( );
    case zz::map::west :
      return west( );
  }
  std::cerr << "invalid direction provided to map::location::adjacent" << std::endl;
  exit( 1 );
}

/******************************************************************************
 * Map Construction
 ******************************************************************************/
zz::map::map( )
: _width( -1 ), _height( -1 ), _player_one( -1, -1 ), _player_two( -1, -1 ), _is_wall( ), _counted_locations() {
}

zz::map::map( const zz::map& map )
: _width( map._width ), _height( map._height ), _player_one( map._player_one ), _player_two( map._player_two ), _is_wall( ), _counted_locations() {
  memcpy( _is_wall, map._is_wall, _width * _height * sizeof(int ) );
}

zz::map::map( const std::string& filename )
: _width( -1 ), _height( -1 ), _player_one( -1, -1 ), _player_two( -1, -1 ), _is_wall( ), _counted_locations() {
  FILE* f = fopen( filename.c_str(), "r" );
  if( f ) {
    load_from_file( f );
    fclose( f );
  }
}
zz::map::~map( ) {
}

void zz::map::load_from_file( FILE *file_handle ) {
  int x, y, c;
  int num_items = fscanf( file_handle, "%d %d\n", &_width, &_height );
  if( feof( file_handle ) || num_items < 2 ) {
    exit( 0 ); // End of stream means end of game. Just exit.
  }

  x = 0;
  y = 0;
  while( y < _height && ( c = fgetc( file_handle ) ) != EOF ) {
    switch( c ) {
      case '\r':
        break;
      case '\n':
        if( x != _width ) {
          fprintf( stderr, "x != width in Board_ReadFromStream\n" );
          return;
        }
        ++y;
        x = 0;
        break;
      case '#':
        if( x >= _width ) {
          fprintf( stderr, "x >= width in Board_ReadFromStream\n" );
          return;
        }
        _is_wall[x + _width * y] = true;
        ++x;
        break;
      case ' ':
        if( x >= _width ) {
          fprintf( stderr, "x >= width in Board_ReadFromStream\n" );
          return;
        }
        _is_wall[x + _width * y] = false;
        ++x;
        break;
      case '1':
        if( x >= _width ) {
          fprintf( stderr, "x >= width in Board_ReadFromStream\n" );
          return;
        }
        _is_wall[x + _width * y] = true;
        _player_one = map::location( x, y );
        ++x;
        break;
      case '2':
        if( x >= _width ) {
          fprintf( stderr, "x >= width in Board_ReadFromStream\n" );
          return;
        }
        _is_wall[x + _width * y] = true;
        _player_two = map::location( x, y );
        ++x;
        break;
      default:
        fprintf( stderr, "unexpected character %d in Board_ReadFromStream", c );
        return;
    }
  }
}

/******************************************************************************
 * Map Query methods
 ******************************************************************************/
bool zz::map::locations_are_connected( const zz::map::location& start, const zz::map::location& end, bool top_level ) const {
  // We'll need to keep track of all previously counted locations, so we don't double count them
  if( start == end ) return true;

  if( top_level ) {
    memset( _counted_locations, false, _width * _height * sizeof(int) ); // initialize all locations to uncounted
  } else {
    if( is_wall( start ) || _counted_locations[start.x() + _width * start.y()] ) return false;
  };


  //check  this location
  int reachable = false;
  _counted_locations[start.x() + _width * start.y()] = true;

  // check if it is reachable from any of the neighboring areas
  for( int i = 0; i < 4; ++i ) {
    reachable = reachable || locations_are_connected( start.adjacent( i ), end, false );
  }

  return reachable;
}

int zz::map::area_available_from( const zz::map::location& location, bool top_level ) const {
  // We'll need to keep track of all previously counted locations, so we don't double count them
  if( top_level ) {
    memset( _counted_locations, false, _width * _height * sizeof(int) ); // initialize all locations to uncounted
  };

  if( is_wall( location ) || _counted_locations[location.x() + _width * location.y()] ) return 0;

  // count this location
  int available_area = 1;
  _counted_locations[location.x() + _width * location.y()] = true;

  // count all available area for all neighboring locations, that haven't already been counted
  for( int i = 0; i < 4; ++i ) {
    available_area += area_available_from( location.adjacent( i ), false );
  }

  return available_area;
}

void zz::map::voronoi_territory( int& player_one_area, int& player_two_area, bool top_level ) const {
  player_one_area = 0;
  player_two_area = 0;
  for(int i = 0; i < _width; ++i ){
    for(int j = 0; j < _height; ++j ){
      zz::map::location location(i,j);
      if( is_wall( location ) ){
        continue;
      }
      if( ! locations_are_connected( location, _player_one) ) {
        ++player_two_area;
      } else if( ! locations_are_connected( location, _player_two)) {
        ++player_one_area;
      } else {
        int player_one_dist = abs(_player_one.x() - location.x()) + abs(_player_one.y() - location.y());
        int player_two_dist = abs(_player_two.x() - location.x()) + abs(_player_two.y() - location.y());
        if( player_one_dist < player_two_dist ) {
          ++player_one_area;
        } else if( player_one_dist > player_two_dist ) {
          ++player_two_area;
        }
      }
    }
  }
//  if( top_level ) {
//    player_one_area = 0;
//    player_two_area = 0;
//    memset( _counted_locations, false, _width * _height * sizeof(int) ); // initialize all locations to uncounted
//  } else {
//    if( is_wall( location ) || _counted_locations[location.x() + _width * location.y()] ) return;
//    // count this location
//    bool player_one_is_connected
//  }
//  _counted_locations[location.x() + _width * location.y()] = true;
//
//  // count all available area for all neighboring locations, that haven't already been counted
//  for( int i = 0; i < 4; ++i ) {
//    voronoi_areas( player_one_area, player_two_area, location.adjacent( i ), false );
//  }
}

bool zz::map::operator ==( const zz::map& map ) {
  return std::equal( _is_wall, _is_wall + ( _height * _width ), map._is_wall );
}

std::ostream & operator<<( std::ostream& output, const zz::map& map ) {
  for( zz::map::coordinate y = 0; y < map.height( ); ++y ) {
    for( zz::map::coordinate x = 0; x < map.width( ); ++x ) {
      zz::map::location location( x, y );
      if( map.player_one( ) == location ) {
        output << "1";
      } else if( map.player_two( ) == location ) {
        output << "2";
      } else if( map.is_wall( x, y ) ) {
        output << "#";
      } else {
        output << " ";
      }
    }
    output << std::endl;
  }
}

std::ostream & operator<<( std::ostream& output, const zz::map::location& location ) {
  output << "(" << (int) location.x() << "," << (int) location.y() << ")";
}
