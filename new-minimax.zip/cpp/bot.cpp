/* 
 * File:   Bot.cpp
 * Author: montana
 * 
 * Created on February 8, 2010, 2:49 PM
 */
#include "bot.h"

zz::bot::bot( )
: _map( ) {
  std::cerr << "Initialized new bot" << std::endl;
}

zz::bot::~bot( ) {
}

// 1. If opponent is unreachable: land_fill
// 2. Select moves that lead to the most available area
// 3. If there is more than one with the most available area, minimax

void zz::bot::move( ) {
  _map.load_from_file( stdin );

  // if there is 1 move with more area than all other, take it
  std::map<zz::map::direction, int> directions_area_scores = max_available_areas( );
  if( directions_area_scores.size( ) == 1 )
    return output_move( ( *directions_area_scores.begin( ) ).first );

  std::map<zz::map::direction, int> directions_minimax_scores = minimax( _map );
  int max_score = ( *( std::max_element( directions_minimax_scores.begin( ), directions_minimax_scores.end( ), map_value_comparator ) ) ).second;
  for( std::map<zz::map::direction, int>::iterator it = directions_minimax_scores.begin( ); it != directions_minimax_scores.end( ); ++it ) {
    if( ( *it ).second != max_score ) directions_minimax_scores.erase( it ); // remove all directions, except the ones with that lead to the max_area
  }
  return output_move( ( *(directions_minimax_scores.begin( ) )).first );

}

std::map<zz::map::direction, int> zz::bot::minimax( zz::map& map, int depth ) {
  // calculate the outcome of all possible moves by player_one
  int max = -1000;
  std::map<zz::map::direction, int> mins;
  for( zz::map::direction i = zz::map::north; i <= zz::map::west; ++i ) {
    mins[i] = 1000;
    for( zz::map::direction j = zz::map::north; j <= zz::map::west; ++j ) {
      if( mins[i] < max ) break;
      zz::map::location player_one = map.player_one().adjacent( i );
      zz::map::location player_two = map.player_two().adjacent( j );
      bool player_one_dies = map.is_wall( player_one );
      bool player_two_dies = map.is_wall( player_two );
      bool collision = player_one == player_two;
      int result;
      if( collision || ( player_two_dies && player_one_dies ) ) {
        // draw
        result = -500;
      } else if( player_two_dies && !player_one_dies ) {
        // win
        result = 1000;
      } else if( !player_two_dies && player_one_dies ) {
        // loss
        result = -1000;
      } else {
        // nothing exciting happened
        if( depth < 7 ) {
          // look ahead at the next max;
          zz::map next_move( map );
          next_move.set_player_one( player_one );
          next_move.set_player_two( player_two );
          std::map<zz::map::direction, int> next_mins = minimax( next_move, depth + 1 );
          int max = ( *( std::max_element( next_mins.begin( ), next_mins.end( ), map_value_comparator ) ) ).second;
          result = 0.95 * max;
        } else {
          result = 0;
        }
      }
      if( result < mins[i] ) mins[i] = result;
    }
    if( mins[i] > max ) {
      max = mins[i];
    }
  }
//  for (int i = 0; i < depth; ++i) {
//    std::cerr << "  "; // indent
//  }
//  std::cerr << "returning: [";
//  for( std::map<zz::map::direction, int>::iterator it = mins.begin( ); it != mins.end( ); ++it ) {
//    std::cerr << (int) ( *it ).first << ":" << (int) ( *it ).second << ", ";
//  }
//  std::cerr << "]" << std::endl;

  return mins;
}


// returns a std::map<direction, available_area> with weak directions removed

std::map<zz::map::direction, int> zz::bot::max_available_areas( ) {
  // calculate the available areas in all 4 cardinal directions
  std::map<zz::map::direction, int> available_areas;
  zz::map::location location = _map.player_one( );
  for( zz::map::direction i = zz::map::north; i <= zz::map::west; ++i ) {
    available_areas[i] = _map.area_available_from( location.adjacent( i ) );
  }

  // trim the low areas from the result set
  int max_area = ( *( std::max_element( available_areas.begin( ), available_areas.end( ), map_value_comparator ) ) ).second;
  for( std::map<zz::map::direction, int>::iterator it = available_areas.begin( ); it != available_areas.end( ); ++it ) {
    if( ( *it ).second != max_area ) available_areas.erase( it ); // remove all directions, except the ones with that lead to the max_area
  }

  return available_areas;
}

void zz::bot::land_fill( ) {
  output_move( 0 );
}

void zz::bot::output_move( zz::map::direction direction ) {
  // The four possible moves the contest engine recognizes are:
  //   * 1 -- North. Negative Y direction.
  //   * 2 -- East. Positive X direction.
  //   * 3 -- South. Positive X direction.
  //   * 4 -- West. Negative X direction.
  int move = 1;
  switch( direction ) {
    case zz::map::north :
        move = 1;
      break;
    case zz::map::east :
        move = 2;
      break;
    case zz::map::south :
        move = 3;
      break;
    case zz::map::west :
        move = 4;
      break;
  }
  std::cerr << "Outputting move: " << ( int ) move << std::endl;
  std::cout << ( int ) move << std::endl;
}
