/* 
 * File:   bot.h
 * Author: montana
 *
 * Created on February 8, 2010, 2:49 PM
 */

#ifndef _ZZ_BOT_H
#define	_ZZ_BOT_H

#include "map.h"
#include "util.h"

#include <algorithm>
#include <map>

namespace zz {

  class bot {

  public:
    bot( );
    virtual ~bot( );

    void move( );

  private:

    // returns the bots best move
    void land_fill( );

    std::map<zz::map::direction, int> minimax( zz::map &map, int depth = 0 );
    std::map<zz::map::direction, int> max_available_areas( );

    // Sends the bots move to the contest engine.
    void output_move( zz::map::direction direction );

    zz::map _map;
  };
}

#endif	/* _ZZ_BOT_H */

